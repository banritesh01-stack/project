# AUREVIA Java Backend

Spring Boot authentication backend for the AUREVIA login/signup pages.

## Requirements
- Java JDK 17 or newer
- Maven 3.6+ (or open this project in IntelliJ IDEA and let it import Maven dependencies)

## Run
From this folder, run:

```bash
mvn spring-boot:run
```

The backend starts at `http://localhost:8080`.

## API routes

| Method | URL | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Log in |
| GET | `/api/auth/me` | Check current session |
| POST | `/api/auth/logout` | Log out |

Example login/register JSON:

```json
{
  "email": "person@example.com",
  "password": "at-least-8-characters"
}
```

## Connect the frontend
Serve the frontend from `http://localhost:5500` (for example, VS Code Live Server).
The login request must use `credentials: "include"` so the browser sends the session cookie.

```javascript
const response = await fetch("http://localhost:8080/api/auth/login", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  credentials: "include",
  body: JSON.stringify({ email, password })
});
```

If your frontend uses a different address/port, update the allowed origins in
`AuthController.java`.

## Database
The project includes H2 as a local development database so it can run immediately.
To use a different database, replace the H2 dependency in `pom.xml` with the
appropriate JDBC driver and update `src/main/resources/application.properties`
with your database URL, username, and password.

## Important before public deployment
This is a starter authentication backend, not a production-hardened deployment.
Before exposing it publicly, configure CSRF protection appropriate for cookie-based
sessions, HTTPS and secure cookies, login rate limiting, stricter CORS origins,
and production database credentials via environment variables.
