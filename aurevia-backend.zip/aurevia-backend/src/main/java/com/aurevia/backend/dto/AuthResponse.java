package com.aurevia.backend.dto;

public record AuthResponse(Long id, String email, String message) {}
